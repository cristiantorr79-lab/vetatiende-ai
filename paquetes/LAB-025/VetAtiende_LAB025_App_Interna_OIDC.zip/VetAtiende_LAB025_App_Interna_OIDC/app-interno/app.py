import os
import uuid
import requests
import streamlit as st

st.set_page_config(page_title="VetAtiende AI | Operación interna", page_icon="🏥", layout="wide")

WEBHOOK_URL = os.getenv("N8N_LAB025_WEBHOOK_URL", "").strip()
INTERNAL_KEY = os.getenv("VETATIENDE_INTERNAL_KEY", "").strip()
IDENTITY_PROVIDER = os.getenv("VETATIENDE_IDENTITY_PROVIDER", "").strip()


def text(v):
    return "" if v is None else str(v).strip()


def claim(name):
    try:
        return text(st.user.get(name, ""))
    except Exception:
        try:
            return text(getattr(st.user, name))
        except Exception:
            return ""


def call_lab025(action, **fields):
    generic_error = {
        "ok": False,
        "action": action,
        "message": "No fue posible completar la operación en este momento. Intenta nuevamente.",
        "data": None,
    }

    if not WEBHOOK_URL or not INTERNAL_KEY or not IDENTITY_PROVIDER:
        return 503, generic_error.copy()

    subject = claim("sub")
    if not subject:
        return 401, {
            "ok": False,
            "action": action,
            "message": "No fue posible validar la identidad del usuario.",
            "data": None,
        }

    if "internal_session_id" not in st.session_state:
        st.session_state.internal_session_id = f"interno_{uuid.uuid4().hex}"

    payload = {
        "internal_session_id": st.session_state.internal_session_id,
        "accion": action,
    }
    payload.update({k: v for k, v in fields.items() if v is not None})

    headers = {
        "Content-Type": "application/json",
        "X-VetAtiende-Internal-Key": INTERNAL_KEY,
        "x-vetatiende-identity-provider": IDENTITY_PROVIDER,
        "x-vetatiende-identity-subject": subject,
    }

    try:
        response = requests.post(
            WEBHOOK_URL,
            json=payload,
            headers=headers,
            timeout=45,
        )
    except (requests.Timeout, requests.RequestException):
        return 503, generic_error.copy()

    try:
        result = response.json()
    except ValueError:
        return 503, generic_error.copy()

    if not isinstance(result, dict):
        return 503, generic_error.copy()

    # Los errores 5xx nunca se muestran directamente aunque el backend cambie.
    if response.status_code >= 500:
        return response.status_code, generic_error.copy()

    # Solo se propagan respuestas JSON estructuradas del contrato interno.
    if "ok" not in result or "message" not in result:
        return 503, generic_error.copy()

    return response.status_code, result


def show_result(status, result):
    msg = text(result.get("message")) or "Operación completada."
    if result.get("ok") is True:
        st.success(msg)
    elif status in (401, 403):
        st.error(msg)
    elif status in (404, 409):
        st.warning(msg)
    else:
        st.error(msg)


def run(action, **fields):
    with st.spinner("Procesando..."):
        status, result = call_lab025(action, **fields)
    show_result(status, result)
    return status, result


if not st.user.is_logged_in:
    st.title("VetAtiende AI")
    st.subheader("Operación interna protegida")
    st.write("Acceso exclusivo para personal autorizado. La identidad se verifica mediante OIDC.")
    if st.button("Ingresar", type="primary", use_container_width=True):
        st.login()
    st.stop()

subject = claim("sub")
if not subject:
    st.error("No fue posible validar la identidad de esta sesión.")
    if st.button("Cerrar sesión"):
        st.logout()
    st.stop()

name = claim("name") or claim("given_name") or "Usuario autenticado"
email = claim("email")

c1, c2, c3 = st.columns([3, 2, 1])
with c1:
    st.title("VetAtiende AI")
    st.caption("Operación interna protegida · LAB-025")
with c2:
    st.write(f"**{name}**")
    if email:
        st.caption(email)
with c3:
    if st.button("Cerrar sesión", use_container_width=True):
        st.logout()

with st.expander("Identidad OIDC de esta sesión"):
    st.write("**Proveedor:**", IDENTITY_PROVIDER)
    st.write("**Subject (`sub`):**", subject)
    st.caption("La clínica, el rol, el estado y los permisos los resuelve LAB-025; no vienen del navegador.")

page = st.sidebar.radio("Operación", ["Luna interna", "Alertas", "Pendientes", "Derivaciones", "Tareas"])

if page == "Luna interna":
    st.header("Luna interna")
    q = st.text_area("Consulta", height=140)
    if st.button("Consultar", type="primary", disabled=not q.strip()):
        status, result = run("consulta_rag_interno", message=q.strip())
        if result.get("ok") is True:
            st.markdown(text(result.get("message")))
            data = result.get("data") or {}
            if data.get("requiere_revision_humana") is True:
                st.warning("Esta respuesta requiere revisión humana.")
            sources = data.get("fuentes") or []
            if sources:
                with st.expander("Fuentes internas autorizadas"):
                    for src in sources:
                        st.write(src)

elif page == "Alertas":
    st.header("Alertas operativas")
    if st.button("Actualizar alertas", type="primary"):
        status, result = run("ver_alertas")
        if result.get("ok") is True:
            st.session_state.alertas = (result.get("data") or {}).get("alertas") or []

    alerts = st.session_state.get("alertas", [])
    if not alerts:
        st.info("Pulsa “Actualizar alertas” para consultar las alertas activas.")
    for a in alerts:
        aid = text(a.get("alert_id"))
        state = text(a.get("estado_operacion")).lower()
        with st.container(border=True):
            st.write(f"**Alerta:** `{aid}`")
            st.write(f"**Estado:** {state}")
            st.caption(f"Episodio: {text(a.get('episode_id'))} · Actualizada: {text(a.get('fecha_actualizacion'))}")
            b1, b2, b3 = st.columns(3)
            with b1:
                if st.button("Reconocer", key=f"rec_{aid}", disabled=state != "pendiente"):
                    run("reconocer_alerta", recurso_id=aid)
                    st.session_state.pop("alertas", None)
            with b2:
                if st.button("Iniciar atención", key=f"att_{aid}", disabled=state != "reconocida"):
                    run("actualizar_alerta", recurso_id=aid, estado_objetivo="en_atencion")
                    st.session_state.pop("alertas", None)
            with b3:
                if st.button("Cerrar", key=f"close_{aid}", disabled=state != "en_atencion"):
                    run("actualizar_alerta", recurso_id=aid, estado_objetivo="cerrada")
                    st.session_state.pop("alertas", None)

elif page == "Pendientes":
    st.header("Pendientes")
    t1, t2 = st.tabs(["Crear", "Actualizar"])
    with t1:
        with st.form("create_pending"):
            tipo = st.text_input("Tipo")
            desc = st.text_area("Descripción")
            priority = st.selectbox("Prioridad", ["baja", "media", "alta"], index=1)
            assignee = st.text_input("Usuario asignado (opcional)")
            submit = st.form_submit_button("Crear pendiente", type="primary")
        if submit:
            run("crear_pendiente", tipo=tipo.strip(), descripcion=desc.strip(), prioridad=priority, asignado_a=assignee.strip())
    with t2:
        rid = st.text_input("ID del pendiente")
        change_state = st.checkbox("Cambiar estado")
        target = st.selectbox("Nuevo estado", ["en_proceso", "resuelto"], disabled=not change_state)
        change_priority = st.checkbox("Cambiar prioridad")
        new_priority = st.selectbox("Nueva prioridad", ["baja", "media", "alta"], disabled=not change_priority)
        change_assignee = st.checkbox("Cambiar usuario asignado")
        new_assignee = st.text_input("Nuevo usuario asignado", disabled=not change_assignee)
        if st.button("Actualizar pendiente", type="primary"):
            fields = {"recurso_id": rid.strip()}
            if change_state:
                fields["estado_objetivo"] = target
            if change_priority:
                fields["prioridad"] = new_priority
            if change_assignee:
                fields["asignado_a"] = new_assignee.strip()
            run("actualizar_pendiente", **fields)

elif page == "Derivaciones":
    st.header("Derivaciones")
    t1, t2, t3 = st.tabs(["Ver", "Crear", "Aceptar / resolver"])
    with t1:
        if st.button("Actualizar derivaciones", type="primary"):
            status, result = run("ver_derivaciones")
            if result.get("ok") is True:
                data = result.get("data") or {}
                st.session_state.derivaciones = data.get("derivaciones") or data.get("referrals") or []
        rows = st.session_state.get("derivaciones", [])
        if rows:
            st.dataframe(rows, use_container_width=True, hide_index=True)
        else:
            st.info("Pulsa “Actualizar derivaciones” para consultar.")
    with t2:
        with st.form("create_referral"):
            origin_type = st.selectbox("Tipo de origen", ["alerta", "pendiente", "tarea"])
            origin_id = st.text_input("ID del recurso de origen")
            reason = st.text_area("Motivo")
            role = st.selectbox("Rol destino", ["recepcion", "veterinario"])
            user = st.text_input("Usuario destino (opcional)")
            submit = st.form_submit_button("Crear derivación", type="primary")
        if submit:
            run("crear_derivacion", origen_tipo=origin_type, origen_id=origin_id.strip(), motivo=reason.strip(), rol_destino=role, usuario_destino=user.strip())
    with t3:
        referral_id = st.text_input("ID de la derivación")
        a, b = st.columns(2)
        with a:
            if st.button("Aceptar derivación", type="primary"):
                run("aceptar_derivacion", recurso_id=referral_id.strip())
        with b:
            if st.button("Resolver derivación"):
                run("resolver_derivacion", recurso_id=referral_id.strip())

elif page == "Tareas":
    st.header("Tareas")
    t1, t2 = st.tabs(["Crear", "Actualizar"])
    with t1:
        with st.form("create_task"):
            title = st.text_input("Título")
            desc = st.text_area("Descripción")
            priority = st.selectbox("Prioridad", ["baja", "media", "alta"], index=1)
            assignee = st.text_input("Usuario asignado (opcional)")
            due = st.text_input("Fecha límite ISO (opcional)", placeholder="2026-09-01T18:00:00-04:00")
            submit = st.form_submit_button("Crear tarea", type="primary")
        if submit:
            run("crear_tarea", titulo=title.strip(), descripcion=desc.strip(), prioridad=priority, asignado_a=assignee.strip(), fecha_limite=due.strip())
    with t2:
        task_id = st.text_input("ID de la tarea")
        change_state = st.checkbox("Cambiar estado", key="task_state")
        target = st.selectbox("Nuevo estado", ["en_proceso", "cerrada"], disabled=not change_state)
        change_title = st.checkbox("Cambiar título")
        new_title = st.text_input("Nuevo título", disabled=not change_title)
        change_desc = st.checkbox("Cambiar descripción")
        new_desc = st.text_area("Nueva descripción", disabled=not change_desc)
        change_priority = st.checkbox("Cambiar prioridad", key="task_priority")
        new_priority = st.selectbox("Nueva prioridad", ["baja", "media", "alta"], disabled=not change_priority)
        change_assignee = st.checkbox("Cambiar usuario asignado", key="task_assignee")
        new_assignee = st.text_input("Nuevo usuario asignado", disabled=not change_assignee)
        change_due = st.checkbox("Cambiar fecha límite")
        new_due = st.text_input("Nueva fecha límite ISO", disabled=not change_due)
        if st.button("Actualizar tarea", type="primary"):
            fields = {"recurso_id": task_id.strip()}
            if change_state: fields["estado_objetivo"] = target
            if change_title: fields["titulo"] = new_title.strip()
            if change_desc: fields["descripcion"] = new_desc.strip()
            if change_priority: fields["prioridad"] = new_priority
            if change_assignee: fields["asignado_a"] = new_assignee.strip()
            if change_due: fields["fecha_limite"] = new_due.strip()
            run("actualizar_tarea", **fields)

st.divider()
st.caption("La identidad viene de OIDC. LAB-025 mantiene la autoridad sobre clínica, rol, estado y permisos.")
