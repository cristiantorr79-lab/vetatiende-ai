# VetAtiende AI — LAB-025
## Aplicación interna protegida + OIDC — paquete final validado

Este paquete conserva la segunda aplicación Streamlit utilizada por LAB-025 para la operación interna protegida. La aplicación pública permanece separada.

### Arquitectura final

Navegador → `/interno` → Caddy → `streamlit-interno:8502` → OIDC → `sub` autenticado → webhook interno protegido LAB-025.

El navegador no decide `clinic_id`, `user_id`, rol, estado, permisos ni la clave interna. LAB-025 resuelve la autorización a partir de `identity_provider + identity_subject` y de sus registros internos.

### Archivos

- `app-interno/app.py`
- `app-interno/requirements.txt`
- `app-interno/Dockerfile`
- `app-interno/entrypoint.sh`
- `compose.lab025-interno.yaml`
- `Caddyfile.propuesto`
- `.env.lab025-interno.example`

### Ruta final

- aplicación interna: `https://<APP_HOST>/interno`
- callback OIDC: `https://<APP_HOST>/interno/oauth2callback`

### Red Docker

`streamlit-interno` se conecta explícitamente a la red externa ya existente:

`vetatiende-comercial_vetatiende`

Esto permite comunicarse con `n8n:5678` sin publicar el puerto interno.

### Seguridad validada

- los secretos reales permanecen únicamente en el `.env` operativo y en las credenciales correspondientes;
- la clave interna no se envía al navegador;
- la identidad se obtiene de la sesión OIDC;
- LAB-025 conserva la autoridad sobre clínica, rol, estado y permisos;
- errores de timeout, conectividad, configuración, respuestas 5xx y respuestas no JSON se muestran mediante un mensaje genérico sanitizado;
- la aplicación no expone nombres de nodos, URLs internas, stack traces ni configuración técnica al usuario;
- el paquete no contiene secretos reales.

### Configuración OIDC

El módulo es OIDC genérico. Para el piloto controlado se validó Google como proveedor, sin acoplar la autorización a Google.

Los valores reales de `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET`, `OIDC_COOKIE_SECRET` y `VETATIENDE_INTERNAL_KEY` no deben versionarse.

### Despliegue de referencia

Los archivos de este paquete corresponden a la configuración final validada de LAB-025. En el servidor operativo ya fueron aplicados y probados; el ZIP se conserva como artefacto versionable y reproducible del laboratorio.
