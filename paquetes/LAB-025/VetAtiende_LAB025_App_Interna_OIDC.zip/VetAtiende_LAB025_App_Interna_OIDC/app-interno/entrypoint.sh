#!/bin/sh
set -eu

for var in OIDC_REDIRECT_URI OIDC_COOKIE_SECRET OIDC_CLIENT_ID OIDC_CLIENT_SECRET OIDC_SERVER_METADATA_URL VETATIENDE_IDENTITY_PROVIDER N8N_LAB025_WEBHOOK_URL VETATIENDE_INTERNAL_KEY; do
    eval "value=\${$var:-}"
    if [ -z "$value" ]; then
        echo "Falta variable obligatoria: $var" >&2
        exit 1
    fi
done

mkdir -p /app/.streamlit
chmod 700 /app/.streamlit

python - <<'PY'
import json
import os
from pathlib import Path

def q(name):
    return json.dumps(os.environ[name], ensure_ascii=False)

content = "\n".join([
    "[auth]",
    f"redirect_uri = {q('OIDC_REDIRECT_URI')}",
    f"cookie_secret = {q('OIDC_COOKIE_SECRET')}",
    f"client_id = {q('OIDC_CLIENT_ID')}",
    f"client_secret = {q('OIDC_CLIENT_SECRET')}",
    f"server_metadata_url = {q('OIDC_SERVER_METADATA_URL')}",
    "",
])

path = Path('/app/.streamlit/secrets.toml')
path.write_text(content, encoding='utf-8')
path.chmod(0o600)
PY

exec streamlit run /app/app.py \
    --server.address=0.0.0.0 \
    --server.port=8502 \
    --server.baseUrlPath=interno \
    --browser.gatherUsageStats=false
